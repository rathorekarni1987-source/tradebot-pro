# TradeBot Pro 4.0 Android — build-ready source project

This project packages the user-tested TradeBot Pro Final 3.1 paper simulator into an Android WebView application. **This ZIP is NOT an APK.** The APK must be compiled and tested on a real device.

## Build APK in Android Studio
1. Install Android Studio with Android SDK Platform 35 and JDK 17.
2. Open the `TradeBotProAndroid` folder as a project. Let Gradle sync/download Android Gradle Plugin 8.9.2 and dependencies.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.
5. Transfer the APK to your Android phone and install it after reviewing Android's sideload prompt. The debug APK is for personal testing, not Play Store distribution.

## Data and privacy
- Existing browser/GitHub Pages `localStorage` is separate from this APK's WebView storage.
- To transfer the account, export **Backup JSON** from the existing website, then in the installed app use **Settings > Restore JSON** and choose the saved file.
- APK **Backup JSON** and **Export CSV** open the Android document picker to save the file.
- No broker connectivity, no live trading, no Internet permission, no background trading. Synthetic paper data only.
- Keep backups before upgrading/uninstalling. Android app data can be removed on uninstall.

## Validation status
Source project generated from the provided HTML. Android Studio build and Pixel device install **have not been run** in this environment. Verify APK launch, charts, risk self-tests, Buy/Sell, journal, backup, restore, and persistence before calling it production-ready.
