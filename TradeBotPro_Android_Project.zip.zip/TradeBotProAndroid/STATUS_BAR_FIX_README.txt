TRADEBOT PRO — ANDROID STATUS BAR FIX

This is a replacement for TradeBotPro_Android_Project.zip.
The Android WebView now applies Android system bar/display cutout insets as padding,
so the app header should appear below the clock/battery icons.
The bottom navigation also receives system navigation-bar clearance.

PHONE-ONLY GITHUB STEPS
1. Rename this ZIP to TradeBotPro_Android_Project.zip on your phone.
2. In GitHub repository, replace the old root TradeBotPro_Android_Project.zip with this ZIP.
   GitHub's web upload may reject overwriting an existing binary. If so,
   delete the old ZIP (commit), then upload the renamed replacement (commit).
3. Existing workflow will run on the ZIP change. Check Actions > latest run.
4. Download Artifacts > TradeBotPro-debug-APK, extract app-debug.apk.
5. Install the new APK over the existing one. Keep the same applicationId.

CAUTION: Back up JSON in the installed app before upgrading. Do not uninstall
the old app or clear its storage; uninstalling normally deletes app data.

This source change has not been compiled or device-tested in this environment.
