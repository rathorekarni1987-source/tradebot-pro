TradeBot Pro FIX 3 - header-only adjustment

- Keeps the working Android system-bar/insets fix from FIX2 unchanged.
- Changes only the embedded HTML header styling.
- "Final 3.1" is now a non-breaking version label.
- Slightly tightens the mobile logo typography so the header fits narrow WebView widths.
- Trading logic, storage, navigation, bot simulation and native inset code are unchanged.
