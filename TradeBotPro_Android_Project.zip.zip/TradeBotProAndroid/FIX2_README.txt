TRADEBOT PRO — FIX 2 (SYSTEM BAR OVERLAP)

What changed:
- Android 15+ edge-to-edge is handled explicitly.
- WebView is physically constrained with layout margins, not parent padding.
- Top safe area uses the maximum of status-bar inset, display-cutout inset,
  and Android's status_bar_height resource as a fallback.
- Bottom safe area similarly protects the gesture/navigation region.
- App versionCode = 3, versionName = 4.1-insets-fix2.
- Trading HTML/JavaScript logic was not changed.

Use this ZIP as TradeBotPro_Android_Project.zip in the GitHub workflow.
After building, install the new app over the existing app (same applicationId).
Back up JSON first as a precaution. Do not uninstall unless Android refuses the update.
